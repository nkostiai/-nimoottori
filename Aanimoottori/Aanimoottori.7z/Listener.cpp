#include "Listener.h"

Listener::Listener(double px, double py, double pz, double sx, double sy, double sz)
{
	this->position = Vector3(px, py, pz);
	this->speed = Vector3(sx, sy, sz);
}

Vector3 Listener::getPosition()
{
	return this->position;
}

Vector3 Listener::getSpeed()
{
	return this->speed;
}

void Listener::setPosition(double px, double py, double pz)
{
	this->position = Vector3(px, py, pz);
}

void Listener::setSpeed(double sx, double sy, double sz)
{
	this->speed = Vector3(sx, sy, sz);
}

double Listener::getAttenuationByDistance(double distance)
{
	if (distance < 10) {
		return 1;
	}
	else if (distance > 100) {
		return 0;
	}
	else {
		return 1 - (distance / 100);
	}
}

double Listener::getPanningByLocation(Vector3 location)
{
	return 0.0;
}

double Listener::getDopplerShift(Vector3 location, Vector3 speed) {
	return 1.0;
}
